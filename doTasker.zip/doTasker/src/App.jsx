import React from 'react';
import './App.css';
import { Routes, Route, useNavigate } from 'react-router-dom';
import AddTask from './pages/addTask/AddTask';
import FetchTasks from './pages/fetchTask/FetchTasks';
import DeleteTask from './pages/deleteTask/DeleteTask';

const App = () => {
  const navigate = useNavigate();

  return (
    <div className="container">
      <h1>Do Tasker <br /> (Kaiburr Assignment from Pubesh)</h1>

      <div className="button-group">
        <button onClick={() => navigate('/addTask')}>Add Task</button>
        <button onClick={() => navigate('/fetchTask')}>Fetch Task</button>
        <button onClick={() => navigate('/deleteTask')}>Delete Task</button>
      </div>

      <Routes>
        <Route path="/addTask" element={<AddTask />} />
        <Route path="/fetchTask" element={<FetchTasks />} />
        <Route path="/deleteTask" element={<DeleteTask />} />
      </Routes>
    </div>
  );
};

export default App;
