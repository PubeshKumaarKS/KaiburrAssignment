import React, { useState } from 'react';
import axios from 'axios';
import './AddTask.css';

const AddTask = () => {
  const [task, setTask] = useState({
    id: '',
    name: '',
    owner: '',
    command: ''
  });

  const handleChange = (e) => {
    setTask({ ...task, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:8080/addTask', task);
      alert('Task added successfully!');
      setTask({ id: '', name: '', owner: '', command: '' }); // Reset form
    } catch (error) {
      console.error('Error adding task:', error);
      alert('Failed to add task.');
    }
  };

  return (
    <div className="form-container">
      <h2>Add Task</h2>
      <form onSubmit={handleSubmit}>
        
        <input type="text" placeholder='Enter ID' name="id" value={task.id} onChange={handleChange} required />

        
        <input type="text" placeholder='Enter Name' name="name" value={task.name} onChange={handleChange} required />

        
        <input type="text"  placeholder='Enter Owner Name' name="owner" value={task.owner} onChange={handleChange} required />

        
        <input type="text"  placeholder='Command' name="command" value={task.command} onChange={handleChange} required />

        <button type="submit">Submit</button>
      </form>
    </div>
  );
};

export default AddTask;
