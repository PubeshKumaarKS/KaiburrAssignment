import React, { useState } from "react";
import "./DeleteTask.css";

const DeleteTask = () => {
  const [id, setId] = useState("");

  const handleDelete = async (e) => {
    e.preventDefault();
    if (!id) {
      alert("Please enter an ID!");
      return;
    }

    try {
      const response = await fetch(`http://localhost:8080/deleteTask/${id}`, {
        method: "DELETE",
      });

      if (response.ok) {
        alert(`Task with ID ${id} deleted successfully`);
        setId(""); // Clear input after deletion
      } else {
        alert("Failed to delete task. Task ID may not exist.");
      }
    } catch (error) {
      console.error("Error deleting task:", error);
      alert("An error occurred while deleting the task.");
    }
  };

  return (
    <div className="delete-container">
      <h2>Delete Task</h2>
      <form onSubmit={handleDelete}>
        <input
          type="text"
          placeholder="Enter Task ID"
          value={id}
          onChange={(e) => setId(e.target.value)}
          required
        />
        <button type="submit">Delete</button>
      </form>
    </div>
  );
};

export default DeleteTask;
